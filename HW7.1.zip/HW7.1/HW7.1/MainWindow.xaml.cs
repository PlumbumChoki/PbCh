﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using HW7.Models;
using HW7.Repositories;

namespace HW7._1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();           
            AddCar();

            
        }

        public async void AddCar()
        {
            var car = new Car()
            {
                CarBrand = "Toyota",
                CarModel = "Corolla",
                YearOfManufacturing = "2001",
                EngineCapacity = 1.5,
                CountryOfManufacturing = "Japan"
            };

            var repositoryDB = new RepositoryDB();
            await repositoryDB.AddCarsAsync(car);
        }

        public void RemoveCar(Car car1)
        {
            var repositoryDB = new RepositoryDB();
            repositoryDB.RemoveCarsAsync(car1);
        }


    }

}